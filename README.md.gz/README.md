A [pelican](https://github.com/getpelican/pelican) powered blog.

[http://blog.shajiquan.com](http://blog.shajiquan.com/)

- Beautiful URL Mapping
- Sitemap Support
- CSS file minify
- Google Analytics
- Disqus Comment
- Social share
- Responsive, mobile friendly
